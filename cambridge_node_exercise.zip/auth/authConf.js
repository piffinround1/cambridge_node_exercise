
module.exports = {
	
	facebook: {

	clientID: '1658069641104488',
    clientSecret: 'e50ee5acb1b787ca3e04141992206a6a',
    callbackURL: 'http://localhost:5000/auth/facebook/callback',
    enableProof: false

	},

	twitter: {

		consumerKey :'Y3U65fKExVDasrYEFl0W1Fh0D',
		consumerSecret: 'Xb2XdaKPIZnsmorxYaMEtZFb6oQUiN9cIBsi4gh6N2bv9xjVe7',
		callbackUrl: 'http://127.0.0.1:5000/auth/twitter/callback'
	},	

	local : {


		usernameField : 'email',
		passwordField : 'password',
		passReqToCallback : true


	},
	idm : {
	   /* tokenURL: 'http://idm.platserv-uat-dev.aop.cambridge.org:8180/oauth/token',
	    clientID: 'aop-user-client',
	    profileUrl : 'http://idm.platserv-uat-dev.aop.cambridge.org:8080/aop-idm/identity'  */


	    tokenURL: 'http://idm.dev.aop.cambridge.org:8080/oauth/token',
	    clientID: 'aop-user-client',
	    profileUrl : 'http://idm.dev.aop.cambridge.org:8080/aop-idm/identity'  
  	}
};