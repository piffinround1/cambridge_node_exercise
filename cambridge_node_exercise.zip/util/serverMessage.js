


var serverMsg = {

	serverMsg : function(data, dataProperty){
	
		return {'msg': data[dataProperty]};

	}

}



module.exports = serverMsg;